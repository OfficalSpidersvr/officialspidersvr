Placeholder overlay pack. Vervang met echte MP4 overlays.
